| `Version` | `Update Notes`                                                                                                                                         |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.1.3     | - Updated for Valheim 0.216.9                                                                                                                          |
| 1.0.3     | - Fix the stacking issue. Guess what? It was a fucking exclamation point (a.k.a I forgot to reverse my logic when I changed the configuration options) |
| 1.0.2     | - Fix an issue when using the BepInEx Configuration Manager. The values were no longer valid and needed to be mapped to the game's default ItemTypes.  |
| 1.0.1     | - Fix some configuration values.                                                                                                                       |
| 1.0.0     | - Initial Release.                                                                                                                                     |