| `Version` | `Update Notes`                   |
|-----------|----------------------------------|
| 1.0.1     | - Fix some configuration values. |
| 1.0.0     | - Initial Release.               |